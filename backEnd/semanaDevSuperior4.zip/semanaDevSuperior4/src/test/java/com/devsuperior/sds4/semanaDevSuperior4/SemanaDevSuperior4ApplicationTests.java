package com.devsuperior.sds4.semanaDevSuperior4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemanaDevSuperior4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
